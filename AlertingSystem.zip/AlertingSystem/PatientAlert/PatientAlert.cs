﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;



namespace ViewModel
{
    public class PatientAlert
    {
        public int ReturnValue(string response)
        {
            int value = 1;
            if (response != "Healthy")
            {
                value = 0;
            }
            else
                value = 1;



            return value;
        }



        public int GenerateVitals()
        {
            int value = 1;
            HttpClient client = new HttpClient();



            HttpResponseMessage response = client
                .GetAsync("http://localhost:58905/api/BedConfiguration/GetPatientsFromBedAllotment").Result;
            var content = response.Content.ReadAsStringAsync().Result;
            var patientList = JsonConvert.DeserializeObject<List<string>>(content);



            foreach (var patientId in patientList)
            {
                var response1 = client
                    .PostAsJsonAsync("http://localhost:1080/api/PatientMonitoring/GeneratePatientVitals/", patientId)
                    .Result;
                if (response1.IsSuccessStatusCode)
                {
                    var response2 = client
                        .PostAsJsonAsync("http://localhost:1080/api/PatientAlert/PatientVitalsAlertUponValidation/",
                            patientId).Result;
                    var content1 = response2.Content.ReadAsStringAsync().Result;
                    value = ReturnValue(content1);



                }
                else
                    Console.WriteLine("Generate Error code= " + response.StatusCode);
            }



            return value;
        }
    }
}

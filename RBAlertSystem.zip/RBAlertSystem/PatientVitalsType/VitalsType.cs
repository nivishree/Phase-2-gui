﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientVitalsType
{
    public enum VitalsType
    {
        Spo2,
        PulseRate,
        Temperature
    }
}

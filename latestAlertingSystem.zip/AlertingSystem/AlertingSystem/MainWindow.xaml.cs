﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Windows.Navigation;
using System.Threading;
using System.Windows.Controls;

namespace WpfTutorialSamples.ItemsControl
{
    public partial class ItemsControlDataBindingSample : Window
    {
        public ItemsControlDataBindingSample()
        {
            InitializeComponent();

            
        }

      
    }

   
}